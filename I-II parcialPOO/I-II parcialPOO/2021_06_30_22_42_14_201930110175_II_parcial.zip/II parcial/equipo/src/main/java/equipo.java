//UNIVERSIDAD TECNOLOGICA DE HONDURAS
//Alumno: Delmer Avilez
//Cuenta: 201930110175
/**
 *
 * 
 */
public class equipo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
